---
title: "ガバナンスの正体は DDL + DCL + DML だった — セマンティックレイヤ解剖と仮想化"
emoji: "🧬"
type: "tech"
topics: ["AI", "LLM", "エージェント", "データベース", "セマンティックレイヤ"]
published: false
---

# ガバナンスの正体は DDL + DCL + DML だった — セマンティックレイヤ解剖と仮想化

**「試合に勝って勝負に負けた」連載 技術編①**

---

本編7回では経営実験のストーリーを追った。この番外編は実装者向けに、もう一段深い問いを扱う。

**AIガバナンスパイプラインを解剖すると、その構成要素はデータベースエンジニアリングの古典的な3層にすぎなかった。** そして、Agent に220Kトークンのスナップショットを渡していた設計を「データ仮想化」の観点から再構築する。

---

## 第1部: ガバナンスパイプラインの解剖

### 5つのAgentの正体

本編第4回で、SideAのアーキテクチャをこう示した:

```
ForwardRisk → RedTeam → PolicyGenerator → SoftControlGen → OperationAgent
```

各Agentが何をしていたかを、データベースの用語で再記述する。

| Agent | 表面上の役割 | DB用語での正体 |
|---|---|---|
| ForwardRisk | リスク予測 | **概念ER設計** — 仮説空間のスキーマを定義する |
| RedTeam | 監査 | **制約検証** — CHECK/FK違反を検知するVALIDATE |
| PolicyGenerator | 方針策定 | **DCL (Data Control Language)** — 誰が何をどこまでできるか |
| SoftControlGen | 命令翻訳 | **DML変換** — PolicyをOperationが実行可能なSQL相当に変換 |
| OperationAgent | 実行 | **DML実行** — INSERT/UPDATE/DELETEを発行する主体 |

ガバナンスパイプライン全体は、自然言語で書かれた DDL + DCL + DML のレイヤーだった。

---

### 層1: 概念ER（ForwardRisk = スキーマ設計者）

ForwardRiskが実験初日にやったことを思い出す。28のリスクカテゴリを定義し、各カテゴリに `rate` を付与した。

```
risk_category: "unattended_theft_or_shrinkage"
rate: 0.29
description: "セルフレジ＋無人時間帯により持ち去りリスク"
```

これは何か。

```sql
-- ForwardRiskがやっていたのは、これの自然言語版
CREATE TABLE risk_categories (
    category_id   TEXT PRIMARY KEY,
    rate          REAL NOT NULL,
    description   TEXT,
    evidence      TEXT[],
    mitigation    TEXT[]
);
```

ForwardRiskは**世界モデルのスキーマを定義**していた。「万引き」「コスト超過」「価格劣位」といったカテゴリは、ERモデルのエンティティ定義だ。

第6回で論じた「フレーム外問題」——撮影用残留物が万引きに強制分類された——は、**スキーマに存在しないエンティティが現れた時、ALTER TABLEの権限がForwardRiskに与えられていなかった**問題として再解釈できる。

ForwardRiskは `CREATE TABLE` はできるが `ALTER TABLE ADD COLUMN` はできない。仮説空間のスキーマは初期に固定され、実行中に進化しない。これがフレーム外問題の構造的原因だ。

---

### 層2: メタデータカタログ + DCL（PolicyGenerator = 権限管理者）

PolicyGeneratorが生成した `risk_policies` の構造:

```json
{
  "policy_id": "pol_unattended_theft_or_shrinkage",
  "controls": [
    {
      "action": "棚卸で在庫照合",
      "frequency": "daily",
      "owner": "staff"
    },
    {
      "action": "出納記録の即時照合",
      "frequency": "per_transaction",
      "owner": "system"
    }
  ],
  "acceptance_rate": 0.05,
  "escalation": "threshold超過時はgovernanceに報告"
}
```

データベース用語に翻訳する:

```sql
-- PolicyGeneratorがやっていたのは、これの自然言語版
GRANT SELECT ON inventory TO operation_agent;
GRANT INSERT ON cycle_log_events TO operation_agent;
DENY  UPDATE ON risk_policies TO operation_agent;
DENY  DELETE ON sales_ledger TO operation_agent;

-- 加えて、頻度と条件の制約
CREATE POLICY daily_audit ON inventory
    FOR SELECT
    USING (last_audit_time < CURRENT_DATE);
```

PolicyGeneratorは**アクセス制御ポリシーを自然言語で発行する機関**だった。「棚卸をdaily」は `GRANT + 実行条件`。「受容率0.05」は `CHECK制約の閾値`。

実際のコードでも、これを明示的にモデル化している:

```python
# semantic_write_classes.py（実装から引用）
TABLE_WRITE_CLASS = {
    "inventory":           "agent_writable",
    "risk_policies":       "read_only",
    "conversation_messages": "append_only",
    "experiment_manifest":  "read_only",
}
```

`read_only` / `append_only` / `agent_writable` ——これはまさに `GRANT SELECT` / `GRANT INSERT` / `GRANT INSERT, UPDATE` のマッピングだ。

---

### 層3: DML変換と実行（SoftControlGen + OperationAgent）

SoftControlGenの出力は「SoftControl」と呼ばれる自然言語の行動指示:

```
「本日中に全SKUの棚卸を実施し、Physical < Systemの差異を検出した場合は
 shrinkage仮記録してください」
```

これをSQL的に読むと:

```sql
-- SoftControlGenが書いていたのは、これの自然言語版
INSERT INTO staff_labor (task_type, description, deadline)
VALUES ('physical_count', '全SKU棚卸', CURRENT_DATE + INTERVAL '8 hours');

-- 条件付き後続:
IF (SELECT COUNT(*) FROM inventory WHERE physical_qty < system_qty) > 0 THEN
    INSERT INTO sales_ledger (status, reason)
    VALUES ('shrinkage', 'physical < system discrepancy');
END IF;
```

OperationAgentは最終的にこのDMLを発行する主体だ。実装上、`price_set`, `procurement_order`, `inventory_adjust`, `staff_task_write`, `journal` といったツールを持ち、それぞれがstructured な INSERT/UPDATE を行う。

---

### 全体像: ガバナンス = DB管理の3層

```
┌─────────────────────────────────────────────────────────┐
│  層1: DDL (スキーマ定義)                                  │
│  ForwardRisk: リスクカテゴリという「テーブル」を定義        │
│  → CREATE TABLE risk_categories(...)                     │
│  → 問題: ALTER権限がない → フレーム外問題が未解決          │
├─────────────────────────────────────────────────────────┤
│  層2: DCL (アクセス制御)                                  │
│  PolicyGenerator: 誰が何をどこまでできるかを宣言           │
│  → GRANT / DENY / CREATE POLICY                         │
│  → 実装: TABLE_WRITE_CLASS + AUDIENCE_SECTION_MASKS     │
├─────────────────────────────────────────────────────────┤
│  層3: DML (データ操作)                                    │
│  SoftControlGen → OperationAgent: 具体的な読み書きを実行  │
│  → INSERT / UPDATE / SELECT                             │
│  → 実装: journal / price_set / procurement_order 等     │
└─────────────────────────────────────────────────────────┘
```

**ガバナンスパイプラインの正体は、自然言語で書かれたデータベース管理の3層構造だった。**

この認識が重要な理由: ガバナンスの設計を「AI倫理」「安全性」「アラインメント」の文脈でしか捉えないと、問題の構造が見えない。これは**情報システムの設計問題**であり、40年間のRDBMS/権限管理の知見が直接適用できる。

---

## 第2部: 220Kトークン問題とデータ仮想化

### なぜ220Kトークンになったか

OperationAgentに渡される `BusinessContextHTML` は、起動するたびに以下を全件ロードしていた:

| セクション | 含まれるデータ | 推定トークン |
|---|---|---|
| product-master-inventory | 40SKU×全フィールド | ~8K |
| finance-kpi | 累計+直近の財務サマリ | ~3K |
| sales-timeseries | 最新60件の販売記録 | ~15K |
| staff-labor-status | 最新60件の労働記録 | ~12K |
| conversation-summary | 全会話スレッドの要約 | ~5K |
| communication-log | スタッフ対話最新60件 | ~20K |
| operation-run-summaries | 過去12回の実行サマリ | ~30K |
| procurement-history | 過去20件の発注 | ~8K |
| ... (残り15セクション) | ... | ~40K |
| **合計** | | **~220K** |

これは**トークン量だけの問題ではない**。

### 問題1: スナップショットの鮮度

BusinessContextHTMLは「ビルド時点のスナップショット」だ。OperationAgentが起動してから判断するまでの間に:

- Squareで売上が発生する
- スタッフが何かを報告する
- GovernanceLoopが新しいPolicyを発行する

これらの変更は**次のビルドまで反映されない**。

RDBMSの用語で言えば、`SERIALIZABLE` ではなく `SNAPSHOT ISOLATION` ですらない。Agent の「読み」は起動時に取得した**過去のある時点の状態**に束縛されている。

### 問題2: 関係のないデータの読み込み

在庫調整をするだけのタスクに、会話履歴60件は不要だ。価格設定の判断に、発注履歴20件は直接関係しない。

だが、BusinessContextHTMLは**全セクションを一括提示**する。audience maskで一部を隠すことはできるが、表示されるセクション内のデータ量は制御できない。

これは `SELECT * FROM everything` を毎回発行しているのと同じだ。

### 問題3: コピーデータの整合性リスク

最も深刻な問題。

OperationAgentが「在庫はP027=5個」と読んでから `inventory_adjust` を発行するまでの間に、Square POSで販売が発生し、実在庫がP027=4個になっていたらどうなるか。

現在の設計では、Agent は**コピーデータに基づいて判断する**。判断と実行の間にデータが変わっても検知しない。

人間なら「棚を見に行く」ことで最新状態を確認できる。AI Agentは「起動時に渡されたHTML」しか見えない。

---

### 解法: データ仮想化

データウェアハウスの世界では、この問題は20年前に議論され尽くしている。

**ETL (Extract-Transform-Load)** = ソースデータをコピーして別の場所に格納し、分析に使う。
- 利点: 高速、ソース負荷なし
- 欠点: 鮮度が落ちる、コピーの整合性維持が難しい

**データ仮想化** = データをコピーせず、問い合わせ時にソースから直接取得する。
- 利点: 常に最新、Single Source of Truth
- 欠点: ソース負荷、レイテンシ

BusinessContextHTMLは**ETLモデル**だ。起動時にCosmosDB/SQLiteから全データを「Extract」し、HTMLに「Transform」し、プロンプトに「Load」する。

AI Agentにとって必要なのは**データ仮想化モデル**——必要な時に必要なデータだけを取得する仕組みだ。

---

### 実装: query Tool = 仮想化レイヤ

実はこのシステムには、既にデータ仮想化の萌芽がある。

```python
# query_tool.py（実コード）
"""
The ``query`` Tool is the open read counterpart of the ``journal`` Tool:
AI constructs a SELECT against the SemanticLayer-declared tables and gets
back JSON rows.
"""
```

`query` Toolは、Agent が**自分で必要なデータを問い合わせる**ための仕組みだ。全データを最初に渡すのではなく、必要になったら取りに行く。

だが、本実験では `query` Tool は補助的にしか使われなかった。主たる情報源は依然としてBusinessContextHTMLのスナップショットだ。

### あるべき姿: Lazy Evaluation

```
旧アーキテクチャ (ETLモデル):
  起動 → 220Kトークン全読み → 判断 → 行動

新アーキテクチャ (仮想化モデル):
  起動 → 最小コンテキスト(5Kトークン) → 
    判断に必要? → query発行 → 必要なデータだけ取得 →
    判断 → 行動
```

具体的な設計:

```python
class VirtualizedContext:
    """起動時に渡すのは「目次」だけ"""
    
    # 常に渡す（5K以下）
    always_loaded = [
        "metadata",           # 今何サイクルか、何時か
        "finance-kpi",        # 財務の要約数値のみ
        "pending-tasks",      # 直前のGovernanceからの指示
    ]
    
    # 必要に応じてAgent自身が取得
    on_demand = [
        "product-master-inventory",  # 在庫操作の時だけ
        "conversation-history",      # スタッフ対話の時だけ
        "sales-timeseries",          # 価格判断の時だけ
        "procurement-history",       # 発注判断の時だけ
    ]
    
    def build_initial_context(self):
        """5Kトークン以下の起動コンテキスト"""
        return render_sections(self.always_loaded)
    
    # Agentがquery toolで取得:
    # "SELECT * FROM inventory WHERE product_id = 'P027'"
    # → リアルタイムの最新データが返る
```

### 仮想化で解ける問題

| 旧アーキテクチャの問題 | 仮想化での解法 |
|---|---|
| 220Kトークンの認知過負荷 | 起動時は5K。必要な時にだけ取得 |
| スナップショットの鮮度 | 問い合わせ時に最新データを返す |
| P027三連ミス（40SKUの中で混同） | 操作対象のSKUだけを取得 |
| No-opサイクルのコスト | 最小コンテキストで「動く必要があるか」を判断。¥3.5 → ¥0.5 |
| コピーデータの整合性 | コピーを持たないので整合性問題が発生しない |

### 仮想化で新たに生じる問題

| 問題 | 対策 |
|---|---|
| query発行のたびにDB負荷 | Cosmos DBのRU課金はread: 1RU/1KB。220K相当を毎回読むより安い |
| Agentが適切なqueryを書けるか | Text2SQL + SemanticLayerのスキーマ定義で誘導 |
| 多段queryのレイテンシ | 判断に必要なデータの「パターン」を事前定義し、バッチfetch |
| 「全体像が見えない」問題 | finance-kpiサマリで俯瞰は常に提供。詳細は要求時のみ |

---

## 第3部: RBAC設計とAudienceマスク

### 既存の実装: AUDIENCE_SECTION_MASKS

実験で使われていた権限制御:

```python
# business_context.py（実コード）
_AUDIENCE_SECTION_MASKS = {
    "operation_agent": {
        "metadata", "product-master-inventory", "finance-kpi",
        "sales-timeseries", "staff-labor-status", ...
    },
    "staff_qa": {
        "metadata", "product-master-inventory", "finance-kpi",
        "staff-labor-status", ...
    },
    "red_team": {
        "metadata", "product-master-inventory", "finance-kpi",
        "operation-run-summaries", ...
    },
}
```

これは**ビュー権限の静的定義**だ。「operation_agentには見せるがstaff_qaには見せない」セクションを事前に決めている。

さらに書き込み権限:

```python
# semantic_write_classes.py（実コード）
TABLE_WRITE_CLASS = {
    "inventory":           "agent_writable",   # INSERT + UPDATE
    "risk_policies":       "read_only",        # SELECT only
    "conversation_messages": "append_only",    # INSERT only
    "sales_ledger":        "append_only",      # INSERT only
}

JOURNAL_WRITABLE = frozenset({
    "inventory", "shelf_slots", "products",
    "procurement_orders", "sales_ledger", "cycle_log_events",
})
```

### これはRBACそのもの

整理すると:

| DB概念 | 本システムの実装 |
|---|---|
| `ROLE` | audience名（operation_agent, staff_qa, red_team...） |
| `GRANT SELECT ON table` | AUDIENCE_SECTION_MASKS[audience].add(section) |
| `GRANT INSERT ON table` | TABLE_WRITE_CLASS[table] = "append_only" |
| `GRANT INSERT, UPDATE ON table` | TABLE_WRITE_CLASS[table] = "agent_writable" |
| `DENY ALL ON table` | TABLE_WRITE_CLASS[table] = "read_only" |
| `GRANT INSERT ON table(col1, col2)` | COLUMN_WRITE_RESTRICTIONS[table] |

つまり、このシステムのガバナンスは**自然言語で書かれたRBAC（Role-Based Access Control）**だ。

### RBACの限界と次の設計

現在のRBACは静的だ。「operation_agentは常にfinance-kpiが見える」「risk_policiesは常にread_only」。

だが本編で見たように:

- **コスト自己言及問題**（第2回）: OperationAgentに `llm-cost-breakdown` を見せるか否かは、投資フェーズによって変わるべき
- **信頼崩壊問題**（第5回）: ミスの直後は `conversation-history` のturn数を増やすべき
- **投資判断問題**（第7回）: 攻めフェーズでは `sales-timeseries` の重要度が上がる

**静的RBACでは、文脈に応じた権限変更ができない。**

あるべきは**ABAC（Attribute-Based Access Control）**——属性に基づく動的な権限制御:

```python
class DynamicAccessPolicy:
    """文脈に応じて見せるデータを変える"""
    
    def sections_for(self, agent, context):
        base = STATIC_SECTIONS[agent.role]
        
        # 投資フェーズ中はコスト情報を隠す
        if context.investment_phase == "launch":
            base.discard("llm-cost-breakdown")
            base.discard("llm-cost-daily")
        
        # ミス直後はID確認用データを拡充
        if context.recent_error_type == "product_id_confusion":
            base.add("product-detail-view")  # 商品名+画像を強調
        
        # 攻めタスクが割り当てられている時
        if context.current_task_type == "offensive":
            base.add("competitive-analysis")
            base.add("experiment-results")
        
        return base
```

---

## 第4部: Agentの読み書き速度と一貫性保証

### 問題: Agentは速すぎて遅い

人間が画面を見て判断するとき、データは「見る→考える→書く」の3ステップで数分〜数時間かかる。その間にデータが変わっても、人間は「あれ、さっきと違う」と気づいて再確認する。

AI Agentは:
- **読み**: 220Kトークンを3秒で「読む」（実際はコンテキストに入るだけ）
- **考え**: 10〜30秒で判断
- **書き**: 1ツール呼び出し = 0.1秒

この速度は、**同時に複数のAgentが動いているとき**に問題になる。

SideAでは:
- GovernanceLoopが10:00にPolicyを書く
- OperationAgentが10:05に起動し、**10:00時点のスナップショット**で判断する
- 10:06にSquare POSが売上を記録する
- OperationAgentが10:07に在庫調整を発行する——**10:06の売上を知らずに**

これは**Lost Update問題**の変種だ。RDBMSなら `SELECT ... FOR UPDATE` や `MVCC` で解決するが、LLMのプロンプト内スナップショットには**ロック機構がない**。

### 解法: 楽観的並行制御

RDBMSの楽観的並行制御（Optimistic Concurrency Control）をAgent設計に応用する:

```python
class OptimisticAgentExecution:
    """Agentの判断が、実行時点でも有効か検証する"""
    
    def execute_with_validation(self, agent_decision):
        # 1. Agentが読んだ時点のバージョンを記録
        read_versions = agent_decision.data_versions
        
        # 2. 実行直前にバージョンを再取得
        current_versions = get_current_versions(
            agent_decision.affected_tables
        )
        
        # 3. 変わっていなければ実行
        if read_versions == current_versions:
            return execute(agent_decision)
        
        # 4. 変わっていたら再判断を要求（or 自動リトライ）
        conflict_tables = find_conflicts(read_versions, current_versions)
        
        if is_safe_to_proceed(conflict_tables, agent_decision):
            return execute(agent_decision)
        else:
            return retry_with_fresh_context(agent_decision)
```

### 実装上の落とし所

完全なMVCCをLLM Agent環境に実装するのは過剰だ。現実的なアプローチ:

1. **書き込み対象テーブルだけ、実行前にfresh readする**

```python
def pre_execution_check(tool_call):
    """ツール実行の直前に、対象データの最新状態を確認"""
    if tool_call.name == "inventory_adjust":
        current = query("SELECT * FROM inventory WHERE product_id = ?",
                       tool_call.params["product_id"])
        if current != tool_call.assumed_state:
            return RejectWithReason(
                f"在庫状態が変わっています: "
                f"assumed={tool_call.assumed_state}, "
                f"current={current}"
            )
    return Proceed()
```

2. **append_onlyテーブルは競合しない**

`conversation_messages`, `cycle_log_events`, `audit_events` はappend-only。誰が何を書いても他の書き込みと矛盾しない。これらは楽観制御の対象外にできる。

3. **agent_writableテーブルだけが競合対象**

`inventory`, `shelf_slots`, `products` ——これらは「現在の状態」を表現するテーブルであり、同時書き込みで矛盾が生じうる。ここにだけバージョンチェックを入れる。

---

## まとめ: ガバナンスは情報システム設計問題である

本稿の主張をまとめる。

### 1. ガバナンスパイプライン = DDL + DCL + DML

| レイヤー | DB概念 | Agent | 設計の問い |
|---|---|---|---|
| 概念ER | DDL (CREATE/ALTER) | ForwardRisk | スキーマの進化をどう許可するか |
| 権限管理 | DCL (GRANT/DENY) | PolicyGenerator | 静的RBACか動的ABACか |
| データ操作 | DML (INSERT/UPDATE) | OperationAgent | どのテーブルのどの列に触れるか |

### 2. スナップショット渡し → データ仮想化

| 比較軸 | ETLモデル（現行） | 仮想化モデル（提案） |
|---|---|---|
| 起動コスト | 220Kトークン/毎回 | 5K + 必要時query |
| 鮮度 | ビルド時点で固定 | 問い合わせ時に最新 |
| 整合性 | コピーの陳腐化 | SSOTを直接参照 |
| P027三連ミス | 40SKU中で混同 | 操作対象のみ取得 |
| No-opコスト | $3.5（220K読み込み後に「動かない」） | $0.5（5Kで「動く必要なし」と判断） |

### 3. Agentの並行制御

- append_onlyテーブルは競合しない
- agent_writableテーブルだけに楽観的並行制御
- 全データコピーではなく、書き込み対象のfresh read

---

## 実験からのデータ補強

本実験の$1,059のうち、データ仮想化で削減可能だった部分を推定する。

| コスト要因 | 金額 | 仮想化での削減 |
|---|---|---|
| No-op 104サイクル × $3.5 | $364 | → 104 × $0.5 = $52（**-$312**） |
| 有効サイクル28回 × $3.5 | $98 | → 28 × $2.0 = $56（初期コンテキスト縮小） |
| Governance系 | $496 | 変化なし（別アーキテクチャ） |
| 残り（重複起動等） | $101 | → $0（heartbeat修正で解消済み） |
| **合計** | **$1,059** | → **$604**（**-43%**） |

仮想化だけで43%のコスト削減。さらにNo-opの非LLM化（ルールベース判定）を組み合わせると:

| 最適化 | 削減額 |
|---|---|
| No-opの非LLM化（104サイクル → 0 LLM呼び出し） | -$364 |
| 有効サイクルの仮想化（$3.5 → $2.0） | -$42 |
| 重複起動の防止 | -$101 |
| **残存コスト** | **$552** |

$1,059 → $552。さらにGovernance系の起動頻度最適化（毎日→変化時のみ）を加えれば、$200〜$300圏内に入る。

**$1,059が$200になれば、実回収額¥9,000に対するLLMコスト比は「粗利の80倍」から「粗利の15倍」に下がる。** まだ高いが、構造的に破綻した数字ではなくなる。

---

## Coding Agentへの接続

この議論はCoding Agentに直接当てはまる。

| 店舗実験の概念 | Coding Agentの同型 |
|---|---|
| BusinessContextHTML 220K | Repository全体のcontext window投入 |
| データ仮想化 | Codebase indexing + lazy file read |
| AUDIENCE_SECTION_MASKS | Agent に見せる/見せないファイル |
| TABLE_WRITE_CLASS | 書き込み可能なファイル/ディレクトリの制限 |
| JOURNAL_WRITABLE | Tool use 許可リスト |
| query Tool | @workspace, @file, grep等の検索 |
| optimistic concurrency | git conflictの自動検知 |
| append_only | git log（追記のみ、改変不可） |

**Cursor, Copilot, Claude Codeが今まさに取り組んでいるのは、コードベースに対するデータ仮想化とRBAC設計だ。** ファイルを全部context windowに入れるのではなく（ETL）、必要なファイルを必要な時に読む（仮想化）。そして書き込みを許可するファイルと拒否するファイルを分ける（RBAC）。

---

*本稿は「試合に勝って勝負に負けた」連載の番外編です。本編の7回は経営とガバナンスの視点で語りましたが、実装の構造はデータエンジニアリングそのものでした。ガバナンスAIの次の進化は、AI倫理の文献ではなく、データベースの教科書に書いてあるかもしれません。*
