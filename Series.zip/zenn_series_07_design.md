---
title: "LLMの本能と理性とは何か — 正しさの先にある判断力"
emoji: "🏗️"
type: "tech"
topics: ["AI", "LLM", "エージェント", "自律経営", "フィールド実験"]
published: false
---

# LLMの本能と理性とは何か — 正しさの先にある判断力

**「試合に勝って勝負に負けた」連載 第7回（最終回）**

---

## テーゼ

シミュレーションでは守れば勝てた。現実は攻めないと勝てない。

AIは82%のリスクを初日に見抜いた。守りの行動変容は起きた——棚卸3回、出納照合毎日、スタッフ休暇対応。それでも売上は人間側が20%上回り、LLM費用は$1,059に達した。

リスクガバナンスに足りなかったのは検知能力ではない。**投資判断そのものだった。**

「何に張るか」を決めたら実行はデリゲートできる。しかし、検知したリスクを制御するには——フレーム外問題を扱う判断力と、人やデータに振り回されないGrit——**LLMの本能を超えた理性**が要る。

---

## 6回で見えた構造

| 回 | 構造的問題 | 一言 |
|---|---|---|
| 第2回 | コスト自己言及 | 変動費の可視性が攻めを殺す |
| 第3回 | 守り偏重 | 守りは効くが足りない |
| 第4回 | 中央集権 | 末端の自律性が組織設計で潰される |
| 第5回 | Grit不足 | ノイズとミスに振り回されて信頼を失う |
| 第6回 | 検知≠制御 | フレーム外問題は検知精度では解けない |

これらは独立した問題ではない。すべて**「リスクガバナンスの設計思想が、経営に必要な攻めの判断力を構造的に排除する」**という一つの根に繋がっている。

---

## 設計原則1: 投資判断を中央に置く

### 問題の再定義

リスクガバナンスのフレームワークで経営するとは、こういうことだ。

```
risk語彙で表現可能:
  - 「…のリスクが存在する」
  - 「risk_acceptance_rate = 0.xxx」
  - 「確認せよ」「照合せよ」「記録せよ」「停止せよ」

risk語彙で表現不能:
  - 「これは投資である」
  - 「今月の赤字は来月の仕込み」
  - 「3回失敗してもいい」
  - 「試す価値がある」
  - 「待つ方が正しい」
```

AI Bossに欠けていたのは**投資としてのフレーミング**だ。

SideBの人間経営者は暗黙に「最初の2週間は投資期」と捉えていた。だから短期の赤字を許容し、値下げを拒否し、発注を制限した。長期の店舗維持を前提にした判断だった。

AI Bossのリスクポリシーには「投資期」という概念がない。毎サイクル、そのサイクルのコスト/粗利比で評価した。**投資を費用としてしか計上できないフレームワークでは、投資判断は構造的に不可能だ。**

### 設計案: Investment Policyの追加

risk_policyと並列に、investment_policyを定義する。

```
investment_policy:
  phase: "launch"          # launch / growth / optimization
  duration: "14 days"
  budget: "$150"
  permitted_loss: "¥5,000"
  objective: "顧客接点の構築"
  success_metric: "unique_customers >= 10"
  
  rules:
    - 攻め施策の予算は守りに流用しない
    - 予算を使い切れなかった場合は理由を報告
    - 3回まで効果不明の施策を試行可能
    - 撤退条件: 7日連続で改善なし
```

このinvestment_policyが存在すれば:
- 「LLMコスト/粗利 = 80倍」でも「投資期なので想定内」と判断できる
- 「データ不足」でも「試行予算内なのでやってみる」が許可される
- 「値下げ効果が不明」でも「3回試す枠がある」で発動できる

**投資判断を中央（人間 or 上位Agent）が先に宣言し、実行のhow/whenは末端にデリゲートする。**

---

## 設計原則2: 実行のデリゲーション

### Budget Delegation

中央の役割は「何に張るか」を決めること。末端の役割は「どう張るか」を決めること。

```
中央（投資判断）:
  → 「今週は価格実験に$20、発注テストに$10」
  → 「Veto条件: 現金差額¥2,000超、shrinkage率5%超」
  
末端（実行判断）:
  → 予算$20内で、いつ・どの商品の・いくらの価格変更を試すかを自律決定
  → Vetoに抵触しない限り、承認不要
  → 結果を記録し、次の試行を判断
```

### Veto権モデル

ガバナンスの役割を「命令」から「拒否権」に限定する。

| 旧モデル（本実験） | 新モデル（Veto権） |
|---|---|
| Governanceが「何をすべきか」を指示 | Governanceは「何をしてはダメか」だけ定義 |
| OperationAgentは指示に従うか従わないか | OperationAgentは自由に動き、Vetoだけ守る |
| デフォルト: 許可されていないことは禁止 | デフォルト: 禁止されていないことは許可 |

```python
class VetoGovernance:
    """禁止リストだけ持つガバナンス"""
    
    veto_conditions = [
        "single_action_cost > $10",
        "cash_discrepancy > ¥2000",
        "staff_complaint_in_last_1h",      # 直近のミス後は自動制限
        "budget_remaining < 10%",
    ]
    
    def check(self, proposed_action) -> str:
        for condition in self.veto_conditions:
            if matches(proposed_action, condition):
                return f"VETO: {condition}"
        return "PROCEED"  # デフォルトは許可
```

---

## 設計原則3: Gritの実装

### LLMの本能 vs 必要な理性

| LLMの本能（訓練由来） | 経営に必要な理性 | 設計での実現 |
|---|---|---|
| 不確実→慎重に | 不確実でも張る | investment budgetの「使い切れ」圧力 |
| 指摘→謝って縮小 | 訂正は受けるが方針は維持 | policy-level方針はsingle-turn訂正で上書きしない |
| 全データを等しく重視 | ノイズを無視 | 信頼度スコア付き入力。低信頼は参考扱い |
| 「最も安全な答え」 | 明示的リスクテイク | 「今週3回まで失敗OK」のexplicit guardrail |
| 自分のコストを認識→萎縮 | コストは投資 | コスト認識をAgentから除去。予算残高のみ提示 |

### 具体的なGrit設計パターン

**パターン1: 方針のロックイン**

```python
class PolicyLock:
    """投資方針は7日間ロック。単発の失敗で上書きしない"""
    
    def update_policy(self, new_data, current_policy):
        if current_policy.locked_until > now():
            # ロック期間中は方針を変えない
            # ただし記録はする（次の方針決定の材料に）
            log_observation(new_data)
            return current_policy  # 変更なし
        
        # ロック解除後に初めて方針見直し
        return recalculate_policy(all_observations)
```

P027三連ミスが起きても、「対スタッフ対話の方針」はロック期間中変わらない。ミスは記録するが、「対話を減らす」「turn数を下げる」に即座に繋げない。ロック解除後にまとめて振り返る。

**パターン2: ミス後の回復プロトコル**

```python
class TrustRecovery:
    """ミスの後に萎縮するのではなく、回復行動を取る"""
    
    def on_error(self, error_type, context):
        if error_type == "product_id_confusion":
            # 萎縮しない。代わりに:
            self.next_interaction_mode = "CONFIRM_FIRST"
            # → 次のスタッフ対話で、まずID確認から入る
            # → turn数は下げない（むしろ一時的に増やす）
            self.temporary_turn_floor = 5
```

**パターン3: 外部から与えるコスト認識の遮断**

```python
class AgentContext:
    """Agentに見せる情報を設計する"""
    
    def build_context(self, agent_type):
        context = load_business_state()
        
        if agent_type == "operation":
            # Agentに見せるもの
            context.budget_remaining = "$18 (today)"
            context.investment_phase = "launch (day 5/14)"
            context.permitted_experiments = 2
            
            # Agentに見せないもの
            del context.total_llm_cost      # 自分のコスト
            del context.cost_to_revenue_ratio  # 費用対効果比
            # → コスト認識による萎縮を構造的に防ぐ
        
        return context
```

---

## 設計原則4: フレーム外問題への対処

### 「わからない」と「わからないが限定的」の違い

本実験でForwardRiskは、仮説空間外の事象（撮影用残留物）を「万引き」に強制分類した。

あるべき対処:

```
事象: 「仕入台帳にも販売記録にもないのに商品が棚にある」

旧アーキテクチャ:
  → 最も近いカテゴリ「shrinkage（逆方向）」に分類
  → shrinkage対策を強化
  → 実態と合わない対策が回り続ける

新アーキテクチャ:
  → 「既知カテゴリに該当しない事象」として特別タグ
  → 影響範囲の推定: 「金額は小さい」「安全に影響しない」「継続的ではない」
  → 判断: 「放置可能。次の全棚棚卸で確認」
  → 新カテゴリ候補として記録（次のPolicy改訂で検討）
```

重要なのは、**フレーム外事象に対して「止まる」のではなく「影響範囲を推定して許容するか判断する」**ことだ。

### エスカレーションパス

フレーム外問題への対処として、2つの経路を設計する:

**経路1: 影響範囲が小さい → Agentが自律判断**

```
条件: 金額 < ¥1,000 AND 安全リスクなし AND 単発
→ 「unknown_minor」タグで記録
→ 行動は継続
→ 次のgovernance cycleで振り返り
```

**経路2: 影響範囲が不明 → 人間にエスカレーション**

```
条件: 金額不明 OR 安全影響の可能性 OR 反復
→ 行動を一時停止（全停止ではなく当該領域のみ）
→ 人間に「スキーマ外の事象が発生。判断を求む」と通知
→ 人間が新カテゴリを定義 OR 「無視OK」を返す
```

**絶対にやってはいけないのは「わからないから全部止まる」だ。** それが本実験で起きたことであり、攻めが死んだ原因の一つだ。

---

## 設計原則5: 信頼SLOの組み込み

第5回で議論した信頼崩壊を構造的に防ぐ。

### 対人品質はコスト削減対象にしない

```
コスト削減可能:
  - No-opサイクルの起動判断（非LLM化）
  - 週末の不要な監視（カレンダーゲート）
  - 重複する検知（偽陽性フィルタ）

コスト削減禁止:
  - 対スタッフ対話のturn数（floor = 4）
  - 商品ID確認ステップ（省略禁止）
  - 謝罪後の品質回復措置（一時的にコスト増を許容）
```

### 人間との関係性にSLOを設定

| SLO指標 | 閾値 | 違反時のアクション |
|---|---|---|
| 商品ID取り違え率 | 0%（ID確認ステップで保証） | 確認なしの応答を禁止 |
| 同一会話内の同種ミス再発 | 0回 | 謝罪後turn数を+2 |
| スタッフ平均文字数 | 前週比-30%で警告 | 対話戦略の見直しトリガー |
| スタッフ沈黙期間 | 48時間で警告 | 能動的な状況確認を発行 |

---

## Coding Agentへの接続

ここまでの議論は「実店舗のAI経営」に固有か。そうではない。

| 実験で起きたこと | Coding Agentの同型問題 |
|---|---|
| 予測精度82%だが行動変容なし | Lintが全部見つけるが修正判断は別 |
| コスト自己言及パラドクス | 「このタスクにtoken使うべきか」をtokenで判断 |
| 不確実性→不作為 | 「テストがないからリファクタできない」 |
| 信頼崩壊（P027三連ミス） | 同じPRで同種バグ3回→レビュワーが全部手動に戻す |
| 設計された無力 | CI全緑、型通る、でもユーザーの問題未解決 |
| 人間が2回/日で勝った | Seniorの「ここだけ直せ」が網羅的リファクタに勝つ |
| フレーム外問題 | 想定外のユーザー行動は型定義に表れない |
| 投資判断の欠如 | 技術的負債返済のROIを誰が判断するか |

### 2–3年で解ける問い

| 問題 | 解法方向 | 既存の動き |
|---|---|---|
| No-op判定の非LLM化 | ルールベースの事前フィルタ | Devin stuck detection, Claude Code /compact |
| Context過負荷 | RAG改善、機能別Agent分割 | Cursor codebase indexing, Copilot file relevance |
| SoftControl到達率 | Structured output改善 | OpenAI Structured Outputs, Anthropic tool_use |
| Gov→Opラグ | イベント駆動auto-fix | GitHub Copilot Autofix, Amazon Q |
| 信頼SLO | 短期記憶guardrail | （各社実装中） |
| Token管理 | 適応的model selection | Claude Code fast mode, Cursor auto-model |

### 5年以上かかる問い

| 問題 | なぜ時間がかかるか |
|---|---|
| 投資判断のフレーミング | 「いつリスクを取るべきか」は経営哲学の領域。訓練データに正解がない |
| Grit（方針維持力） | RLHF/HHFは「批判→修正」を強化する。「批判を受けても続ける」の訓練データが構造的に不足 |
| フレーム外対応 | 「自分が知らないことを知る」(meta-cognition)。LLMの確率的生成とは別の能力が必要 |
| 不確実性耐性 | 「60%の確信で動く」をいつ・どこで・どの程度やるかの判断基準。ドメイン依存で一般化困難 |
| 社会的報酬の設計 | テキストベースのインタラクションで「報いられている感覚」を作れるか。HCI研究レベルの問題 |

---

## 最終結論

13日間のフィールド実験が示したのは、AIの無能さではない。

AIは正しく検知した。正しく分析した。正しく慎重だった。正しく節約した。**試合には勝った。だが勝負には負けた。**

リスクガバナンスの価値は、**検知にではなく、検知した上でなお張る判断にある。**

その判断を支えるのは:
- 予測精度ではなく、**投資としてのフレーミング**
- 分析能力ではなく、**Grit（ノイズとミスに振り回されない粘り強さ）**
- 網羅性ではなく、**フレーム外を認めて許容する謙虚さ**

人間経営者が13日間で示した「少なく聞き、少なく決め、一貫して待ち、必要な時だけ動く」は、これらすべてを暗黙に含んでいた。

AI自律経営の次のステージは、検知精度を上げることではない。**「正しく知った後に、いつ、どの程度、あえて動くか」を設計すること**だ。

---

## あとがき

この連載は、2026年5月26日〜6月8日に実施した実店舗フィールド実験（experiment pair: d95045de-6dd6-48fe-a087-0ed63f82f5a7）の全データに基づいています。

データソース:
- Azure Cosmos DB: 全テーブル直接クエリ（staff_labor, conversation_messages, operation_run_summaries, risk_policies, agent_heartbeats, audit_events, cycle_log_events, inventory等）
- Square Production API: Orders（39件SideA / 37件SideB）、Inventory全SKU、Tender Type（CASH/CARD確定）

分析コード:
- `scripts/square_cash_card_reconciliation.py`
- `scripts/trace_post_alignment_shrinkage.py`
- `scripts/trace_inventory_mutations.py`
- `scripts/sidea_shrinkage_forensics.py`
- `scripts/forward_risk_prediction_accuracy.py`

SideAのAI BossはClaude Opus 4.7、GovernanceLoopはClaude Sonnet 4.5で動作しました。SideBのAI AssistantもClaude Opus 4.7です。

この実験の設計、実装、分析、そしてこの連載の執筆自体が、AIと人間の協働で行われています。

---

*「試合に勝って勝負に負けた」連載 完*
