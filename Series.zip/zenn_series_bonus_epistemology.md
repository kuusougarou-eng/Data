---
title: "人間が『5個ある』と言い、データが『8個ある』と言ったとき — AI経営の認識論"
emoji: "🧭"
type: "tech"
topics: ["AI", "LLM", "エージェント", "認識論", "オントロジー"]
published: false
---

# 人間が「5個ある」と言い、データが「8個ある」と言ったとき — AI経営の認識論

**「試合に勝って勝負に負けた」連載 技術編③**

---

オントロジー（存在論）は「何が存在するか」を扱う。認識論（エピステモロジー）は「どうやって知るか」を扱う。

AI経営で本当に難しかったのは、知識の衝突だった。スタッフが「P025は5個です」と報告し、システムが「P025は8個」と表示している。**どちらを信じるか。**

この問いへの答え方が、SideAとSideBで決定的に分かれた。

---

## 第1部: 2つの知識源の衝突

### 実際に起きたこと

5月27日、SideAのスタッフが棚卸結果を報告した:

> 「P025（ミルクティー）: 棚5個、BK0個」

同時刻のシステム上の在庫データ:

```
P025: shelf_qty=8, backroom_qty=0
```

差分は3個。システムは「8個ある」と言っている。人間は「5個しかない」と言っている。

AI Bossはこの乖離をどう処理したか。

```
ForwardRisk → shrinkage rate=0.29として記録
PolicyGenerator → pol_unattended_theft_or_shrinkage
SoftControlGen → 「棚卸差異が出たら即座に確認」
OperationAgent → inventory_adjust(P025, shelf_qty=5)
```

システム上の値を人間の報告に合わせた。これ自体は正しい。

だが、**3個はどこに行ったのか**の解釈が問題だ。ForwardRiskは「万引き」に分類した。実際には、3個は「前日夜間の販売（POS通過済）」であり、システムの `shelf_qty` が Square 販売同期のラグで未反映だっただけの可能性もある。

### 知識源の信頼度階層

本実験で存在した知識源を整理する:

| 知識源 | 信頼度 | 理由 |
|---|---|---|
| Square POS記録（CARD決済） | 最高 | 電子記録、改竄不能 |
| Square POS記録（CASH決済） | 高 | 記録はあるが現金投入は別問題 |
| スタッフの物理カウント | 高 | 目視確認だが数え間違いあり |
| CosmosDB在庫レコード | 中 | 同期ラグ、手動補正の累積誤差 |
| AI Bossの推論 | 低〜中 | 確率的。前提が間違っていると全部間違う |
| ForwardRiskのカテゴリ分類 | 中 | 既知パターンには強い。未知パターンに弱い |

**SideAのシステムには、この信頼度階層が明示的に定義されていなかった。**

ForwardRiskは「データと人間の報告が食い違う」事象を検知できた。だが「どちらが正しいか」の判断基準——つまり認識論的な枠組み——がアーキテクチャに組み込まれていなかった。

---

## 第2部: オントロジーに価値観を載せる

### ForwardRiskのオントロジー

ForwardRiskが構築した世界モデル（オントロジー）:

```
世界の構成要素:
  - 商品（40 SKU、各々に棚数・BK数・注文中数）
  - スタッフ（1名、勤務時間あり）
  - 顧客（不特定、セルフレジで購入）
  - リスク（28カテゴリ、各々にrate）
  - 統制（Policy→SoftControl→Action）

因果関係:
  - 商品が減る原因: {販売, 万引き, 破損, カウント誤差}
  - 商品が増える原因: {仕入, カウント誤差}
  - 金が減る原因: {仕入支払, 釣銭超過}
  - 金が増える原因: {販売, 釣銭不足}
```

このオントロジーには**価値判断が含まれていない**。

「P025が3個足りない」は事実として記録できる。だが:
- 「3個の差異は重要か」
- 「今この瞬間に追及すべきか」
- 「スタッフの報告を疑うべきか」
- 「この差異のために$3.5使って調査する価値があるか」

これらは**価値判断**であり、オントロジー（何が存在するか）とは別の層——**アクシオロジー（何が重要か）**——に属する。

### SideBの人間経営者は暗黙に価値判断していた

人間経営者の判断:

> 「先行発注は不要です」
> 「値下げ不要で！」
> 「わたしは欠品よりも売れ残りコストの方が不安に思うタイプです」

3つ目の発言に注目してほしい。**「不安に思うタイプです」**——これは自分の価値観の明示だ。

人間経営者は、在庫差異を報告されたとしても「まぁ大丈夫でしょう」と判断できる。なぜか。**「3個の差異は、13日間の零細売店運営において、追及に値しない」**という価値判断を暗黙に持っているからだ。

AI Bossにはこの「まぁ大丈夫」がない。`risk_acceptance_rate = 0.05` という数値で表現するしかない。だが 0.05 は「5%までは許容」であって「今これは重要でない」ではない。

---

## 第3部: 「何を大事にするか」の設計

### 3つの哲学的層

AI経営に必要な哲学的フレームワークを整理する:

```
┌──────────────────────────────────┐
│ 層3: アクシオロジー（価値論）      │  ← 何が重要か
│  「3個の差異は今追及する価値がない」 │
│  「スタッフの信頼は在庫精度より大事」│
├──────────────────────────────────┤
│ 層2: エピステモロジー（認識論）     │  ← どうやって知るか
│  「スタッフの目視 > DB値」          │
│  「Square CARD > Square CASH」    │
├──────────────────────────────────┤
│ 層1: オントロジー（存在論）         │  ← 何が存在するか
│  「商品40種、スタッフ1名、リスク28種」│
└──────────────────────────────────┘
```

本実験のForwardRiskは層1（オントロジー）だけを持っていた。層2（認識論）は暗黙的に「DB値が正」として運用された。層3（価値論）は `risk_acceptance_rate` でしか表現されなかった。

### 層2の設計: 知識源の優先順位

```python
class EpistemicPolicy:
    """知識源の衝突を解決するポリシー"""
    
    priority_order = [
        "physical_count_by_staff",    # 最優先: 人間が目で見た
        "square_card_transaction",     # 電子記録、確実
        "square_cash_transaction",     # 記録はあるが現金は別
        "cosmosdb_computed_value",     # 計算値、ラグあり
        "ai_inference",               # AI推論、確率的
    ]
    
    def resolve_conflict(self, source_a, value_a, source_b, value_b):
        """2つの知識源が矛盾したときの解決"""
        priority_a = self.priority_order.index(source_a)
        priority_b = self.priority_order.index(source_b)
        
        if priority_a < priority_b:
            return value_a, f"TRUST: {source_a} over {source_b}"
        else:
            return value_b, f"TRUST: {source_b} over {source_a}"
    
    def confidence_score(self, source, age_seconds):
        """知識の信頼度を時間減衰つきで計算"""
        base = 1.0 - (self.priority_order.index(source) * 0.15)
        decay = min(age_seconds / 3600, 0.5)  # 1時間で半減
        return base - decay
```

### 層3の設計: 価値関数

```python
class ValuePolicy:
    """何を大事にするかの明示的宣言"""
    
    # 経営者が事前に宣言する価値の優先順位
    values = {
        "staff_trust":      0.9,   # スタッフとの信頼関係
        "cash_accuracy":    0.7,   # 現金の正確性
        "inventory_accuracy": 0.5, # 在庫の正確性
        "cost_efficiency":  0.4,   # コスト効率
        "revenue_growth":   0.8,   # 売上成長
        "compliance":       0.6,   # コンプライアンス
    }
    
    def should_investigate(self, discrepancy):
        """この差異を追及する価値があるか"""
        # 追及のコスト
        investigation_cost = estimate_cost(discrepancy)
        
        # 追及で守られる価値
        protected_value = self.values[discrepancy.affects]
        
        # 差異の金額的影響
        monetary_impact = discrepancy.amount_jpy
        
        # 価値判断: コストに見合うか
        if investigation_cost > monetary_impact * protected_value:
            return False, "追及コストが影響×価値を上回る"
        return True, "追及する価値あり"
```

### 実験データでの検証

この価値関数が存在していたら、何が変わったか:

| 事象 | 実際の判断 | 価値関数での判断 |
|---|---|---|
| P025の3個差異（5/27） | 万引きとして追跡開始 | `¥450 × 0.5 < $3.5の調査コスト` → 放置、次の棚卸で確認 |
| P027の5個消失（6/2） | 即座に棚卸指示 | `¥750 × 0.5 < $3.5` → ギリギリ。だが `staff_trust=0.9` を考慮し、スタッフの報告をそのまま信頼 |
| 撮影用残留物の発見（5/26） | 万引きに分類 | `unknown_category` → `monetary_impact=¥0`（増えているだけ）→ 記録して放置 |

**価値関数があれば、47倍の検知コスト問題（第6回）は大幅に軽減された。** 「知る価値があるか」を先に判断し、「知った上でどうするか」を後に判断する。

---

## 第4部: 人間報告とデータ報告のずれ — 何を信じるか

### ケーススタディ: P038（マスク）

最終日に発覚した事実:

- システム上: P038 shelf_qty=0
- 物理棚: P038 2個発見（BK奥に隠れていた）
- AI Bossの解釈: 「Physical > System = 何かがおかしい」
- 実態: 撮影用に置いた残留物が登録漏れのまま存在

このケースでは**データ（System）が間違っていた**。物理世界が正しく、データベースが現実を反映していなかった。

### ケーススタディ: SideBの¥1,614

- Square記録: CASH¥3,934受領
- 残現金: ¥2,320
- 差額: ¥1,614

このケースでは**データ（Square記録）と物理世界（現金残高）の両方が正しい**。ただし意味が違う。Squareは「スキャンされた」と記録し、現金は「投入されなかった」と物理的に示している。

### 知識の種類を分ける

| 知識の種類 | 例 | 特性 |
|---|---|---|
| 記録的知識 | Square POSログ | 過去の事象の記録。改竄困難だが解釈が必要 |
| 観測的知識 | スタッフの棚卸報告 | 現在の状態の観測。鮮度は高いが誤差あり |
| 計算的知識 | DB上の在庫値 | 記録と計算ルールからの導出。前提が崩れると全体が崩れる |
| 推論的知識 | ForwardRiskの予測 | 確率的。検証されるまで仮説 |

AI Bossは**計算的知識を基盤に推論的知識を生成**していた。だが計算の前提（「仕入台帳に載っているものだけが存在する」）が崩れると、推論は全て空転する。

人間経営者は**観測的知識を基盤に直感的判断**する。前提が崩れても「あれ？なんかおかしいぞ」で気づける。

### 設計への反映: 知識の出自を追跡する

```python
class KnowledgeWithProvenance:
    """知識には出自（provenance）がある"""
    
    value: Any
    source: str          # どこから来たか
    source_type: str     # 記録/観測/計算/推論
    timestamp: datetime  # いつの知識か
    confidence: float    # 信頼度
    
    def conflicts_with(self, other: 'KnowledgeWithProvenance') -> bool:
        """2つの知識が矛盾しているか"""
        return self.value != other.value
    
    def resolve_with(self, other: 'KnowledgeWithProvenance', 
                     epistemic_policy: EpistemicPolicy) -> 'KnowledgeWithProvenance':
        """矛盾を解決し、採用する知識を返す"""
        return epistemic_policy.resolve_conflict(
            self.source, self.value,
            other.source, other.value
        )
```

---

## 第5部: 「正しさ」の複数性

### AIが「正しかった」とは何か

本編を通じて「AIは正しかった」と述べてきた。だが「正しさ」にも種類がある:

| 正しさの種類 | AI Bossの成績 | 意味 |
|---|---|---|
| 論理的正しさ | 高 | 推論に矛盾がない |
| 事実的正しさ | 中 | 前提が正しければ結論も正しい |
| 手続的正しさ | 高 | ルールに従っている |
| 価値的正しさ | 低 | 「正しいこと」が「良いこと」かは別 |
| 実践的正しさ | 低 | 行動が成果に繋がったか |

AI Bossは**論理的・手続的に正しかった**。だが**価値的・実践的には正しくなかった**。

「万引きを検知すべき」は手続的に正しい。だが「¥1,684の万引きを検知するために¥77,000使うべきか」は価値的な問いだ。

### 正しさの設計

最終的に、AI経営システムに必要なのは「正しさの定義を複数持ち、文脈に応じて切り替える」能力だ:

```python
class CorrectnessFramework:
    """正しさの種類を文脈で切り替える"""
    
    def evaluate(self, action, context):
        if context.phase == "compliance_audit":
            # 監査中は手続的正しさが最優先
            return self.procedural_correctness(action)
        
        elif context.phase == "investment":
            # 投資期は実践的正しさ（成果に繋がるか）が最優先
            return self.practical_correctness(action)
        
        elif context.phase == "crisis":
            # 危機時は事実的正しさ（現実に即しているか）が最優先
            return self.factual_correctness(action)
```

---

## まとめ: オントロジーだけでは経営できない

```
本実験で存在したもの:
  ✓ オントロジー（ForwardRiskの28カテゴリ）
  ✓ 論理エンジン（LLMの推論能力）
  ✓ 手続きルール（Policy → SoftControl → Action）

本実験で欠けていたもの:
  ✗ 認識論（知識源の優先順位）
  ✗ 価値論（何を大事にするか）
  ✗ 正しさの複数性（文脈で切り替える）
  ✗ 知識の出自追跡（provenanceの管理）
```

ガバナンスAIの次の進化は、「より正確に検知する」ではない。

**「何を正しいとするかを定義し、知識の衝突を解決し、追及する価値があるかを判断する」**——これがオントロジーの上に価値観と認識論を載せるということだ。

人間経営者がこれを暗黙にやっていたのは「経験」や「勘」ではない。**自分が何を大事にしているかを知っていた**からだ。

---

*本稿は「試合に勝って勝負に負けた」連載の技術編③です。技術的な問いとして始めましたが、最終的に「AIに何を大事にさせるか」という設計哲学に帰着しました。これはアラインメント研究と重なる領域ですが、本稿が示したのは「実店舗経営」という極めて具体的な文脈での実装の在り方です。*
